from playsound import playsound
playsound("mouse_click.mp3")
